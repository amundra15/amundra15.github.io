# coding=utf-8

import sys
import re
import sys
import argparse
from progressbar import Bar, ETA, Percentage, ProgressBar
from keras.models import model_from_json

import spacy
import numpy as np
import scipy.io
from sklearn.externals import joblib
from features import get_questions_matrix_sum, get_images_matrix, get_answers_matrix
from features import get_questions_tensor_timeseries
from utils import grouper



VQA_model_file_name = '../models/lstm_att_num_hidden_units_lstm_512_num_hidden_units_mlp_1024_num_hidden_layers_mlp_3_num_hidden_layers_lstm_1.json'
VQA_weights_file_name = '../models/lstm_att_num_hidden_units_lstm_512_num_hidden_units_mlp_1024_num_hidden_layers_mlp_3_num_hidden_layers_lstm_1_epoch_65.hdf5'
vgg_model_path = '../features/coco/vgg_feats.mat'

contractions = {"aint": "ain't", "arent": "aren't", "cant": "can't", "couldve": "could've", "couldnt": "couldn't", \
"couldn'tve": "couldn’t’ve", "couldnt’ve": "couldn’t’ve", "didnt": "didn’t", "doesnt": "doesn’t", "dont": "don’t", "hadnt": "hadn’t", \
					 "hadnt’ve": "hadn’t’ve", "hadn'tve": "hadn’t’ve", "hasnt": "hasn’t", "havent": "haven’t", "hed": "he’d", "hed’ve": "he’d’ve", \
					 "he’dve": "he’d’ve", "hes": "he’s", "howd": "how’d", "howll": "how’ll", "hows": "how’s", "Id’ve": "I’d’ve", "I’dve": "I’d’ve", \
					 "Im": "I’m", "Ive": "I’ve", "isnt": "isn’t", "itd": "it’d", "itd’ve": "it’d’ve", "it’dve": "it’d’ve", "itll": "it’ll", "let’s": "let’s", \
					 "maam": "ma’am", "mightnt": "mightn’t", "mightnt’ve": "mightn’t’ve", "mightn’tve": "mightn’t’ve", "mightve": "might’ve", \
					 "mustnt": "mustn’t", "mustve": "must’ve", "neednt": "needn’t", "notve": "not’ve", "oclock": "o’clock", "oughtnt": "oughtn’t", \
					 "ow’s’at": "’ow’s’at", "’ows’at": "’ow’s’at", "’ow’sat": "’ow’s’at", "shant": "shan’t", "shed’ve": "she’d’ve", "she’dve": "she’d’ve", \
					 "she’s": "she’s", "shouldve": "should’ve", "shouldnt": "shouldn’t", "shouldnt’ve": "shouldn’t’ve", "shouldn’tve": "shouldn’t’ve", \
					 "somebody’d": "somebodyd", "somebodyd’ve": "somebody’d’ve", "somebody’dve": "somebody’d’ve", "somebodyll": "somebody’ll", \
					 "somebodys": "somebody’s", "someoned": "someone’d", "someoned’ve": "someone’d’ve", "someone’dve": "someone’d’ve", \
					 "someonell": "someone’ll", "someones": "someone’s", "somethingd": "something’d", "somethingd’ve": "something’d’ve", \
					 "something’dve": "something’d’ve", "somethingll": "something’ll", "thats": "that’s", "thered": "there’d", "thered’ve": "there’d’ve", \
					 "there’dve": "there’d’ve", "therere": "there’re", "theres": "there’s", "theyd": "they’d", "theyd’ve": "they’d’ve", \
					 "they’dve": "they’d’ve", "theyll": "they’ll", "theyre": "they’re", "theyve": "they’ve", "twas": "’twas", "wasnt": "wasn’t", \
					 "wed’ve": "we’d’ve", "we’dve": "we’d’ve", "weve": "we've", "werent": "weren’t", "whatll": "what’ll", "whatre": "what’re", \
					 "whats": "what’s", "whatve": "what’ve", "whens": "when’s", "whered": "where’d", "wheres": "where's", "whereve": "where’ve", \
					 "whod": "who’d", "whod’ve": "who’d’ve", "who’dve": "who’d’ve", "wholl": "who’ll", "whos": "who’s", "whove": "who've", "whyll": "why’ll", \
					 "whyre": "why’re", "whys": "why’s", "wont": "won’t", "wouldve": "would’ve", "wouldnt": "wouldn’t", "wouldnt’ve": "wouldn’t’ve", \
					 "wouldn’tve": "wouldn’t’ve", "yall": "y’all", "yall’ll": "y’all’ll", "y’allll": "y’all’ll", "yall’d’ve": "y’all’d’ve", \
					 "y’alld’ve": "y’all’d’ve", "y’all’dve": "y’all’d’ve", "youd": "you’d", "youd’ve": "you’d’ve", "you’dve": "you’d’ve", \
					 "youll": "you’ll", "youre": "you’re", "youve": "you’ve"}

articles     = ['a','an','the']
periodStrip  = re.compile("(?!<=\d)(\.)(?!\d)")
commaStrip   = re.compile("(\d)(\,)(\d)")
punct        = [';', r"/", '[', ']', '"', '{', '}',
						 '(', ')', '=', '+', '\\', '_', '-',
						 '>', '<', '@', '`', ',', '?', '!']
manualMap    = { 'none': '0','zero': '0',
'one': '1',
'two': '2',
'three': '3',
'four': '4',
'five': '5',
'six': '6',
'seven': '7',
'eight': '8',
'nine': '9',
'ten': '10'}

def processPunctuation(inText):
	outText = inText
	for p in punct:
		if (p + ' ' in inText or ' ' + p in inText) or (re.search(commaStrip, inText) != None):
			outText = outText.replace(p, '')
		else:
			outText = outText.replace(p, ' ')
	outText = periodStrip.sub("",
								  outText,
								  re.UNICODE)
	return outText

def processDigitArticle(inText):
	outText = []
	tempText = inText.lower().split()
	for word in tempText:
		word = manualMap.setdefault(word, word)
		if word not in articles:
			outText.append(word)
		else:
			pass
	for wordId, word in enumerate(outText):
		if word in contractions:
			outText[wordId] = contractions[word]
	outText = ' '.join(outText)
	return outText

def ValEval(model,VGGfeatures,nlp,weights_file_name):
	# parser = argparse.ArgumentParser()
	# parser.add_argument('-model', type=str, required=True)
	# parser.add_argument('-weights', type=str, required=True)
	# parser.add_argument('-results', type=str, required=True)
	# parser.add_argument('-wordvec', type=str, default='glove')
	# args = parser.parse_args()

	# model = model_from_json(open('models/'+args.model).read())
	# model.load_weights(args.weights)
	# model = model_from_json(open(model_file_name).read())
	# model.load_weights(model_weights_filename)
	# model.compile(optimizer='rmsprop', loss={'output': 'categorical_crossentropy'})

	questions_val = open('../data/preprocessed/questions_val2014.txt',
						'r').read().decode('utf8').splitlines()
	answers_val = open('../data/preprocessed/answers_val2014_all.txt',
						'r').read().decode('utf8').splitlines()
	images_val = open('../data/preprocessed/images_val2014_all.txt',
						'r').read().decode('utf8').splitlines()
	vgg_model_path = '../features/coco/vgg_feats.mat'

	# print 'Model compiled, weights loaded...'
	labelencoder = joblib.load('../models/labelencoder.pkl')

	# features_struct = scipy.io.loadmat(vgg_model_path)
	# VGGfeatures = features_struct['feats']
	# print 'loaded vgg features'
	image_ids = open('../features/coco_vgg_IDMap.txt').read().splitlines()
	img_map = {}
	for ids in image_ids:
		id_split = ids.split()
		img_map[id_split[0]] = int(id_split[1])

	# if ('glove' in args.wordvec):
	# 	nlp = spacy.load('en', vectors='en_glove_cc_300_1m_vectors')
	# 	print 'loaded Glove Vectors...'
	# else:
	# 	nlp = spacy.en.English()
	# 	print 'loaded word2vec Vectors...'

	nb_classes = 1000
	y_predict_text = []
	batchSize = 128
	widgets = ['Evaluating ', Percentage(), ' ', Bar(marker='#',left='[',right=']'),
           ' ', ETA()]
	pbar = ProgressBar(widgets=widgets)

	for qu_batch,an_batch,im_batch in pbar(zip(grouper(questions_val, batchSize, fillvalue=questions_val[0]),
												grouper(answers_val, batchSize, fillvalue=answers_val[0]),
												grouper(images_val, batchSize, fillvalue=images_val[0]))):

		# Uncomment the line below and remove timesteps from the next line for MLP
		timesteps = len(nlp(qu_batch[-1])) #questions sorted in descending order of length
		# X_q_batch = get_questions_matrix_sum(qu_batch,nlp)
		X_q_batch = get_questions_tensor_timeseries(qu_batch, nlp, timesteps)

		# if 'language_only' in args.model:
			# X_batch = X_q_batch
		# else:
		X_i_batch = get_images_matrix(im_batch, img_map , VGGfeatures)
		# X_batch = np.hstack((X_q_batch, X_i_batch))
		# X_batch = [X_q_batch, X_i_batch]
		y_predict = model.predict({'word_vec': X_q_batch, 'img_vec': X_i_batch}, verbose=0)
		# print y_predict['output']
		# print len(y_predict['output'])
		# print len(y_predict['output'][0])
		y_predict = np.asarray([np.argmax(np.asarray(arr)) for arr in y_predict['output']])
		y_predict_text.extend(labelencoder.inverse_transform(y_predict))

		correct_val=0.0
		total=0
		# f1 = open(args.results, 'w')
		# f1 = open('results'+ model_file_name,'w')
		for prediction, truth, question, image in zip(y_predict_text, answers_val, questions_val, images_val)[:2000]:
			prediction      = prediction.replace('\n', ' ')
			prediction      = prediction.replace('\t', ' ')
			prediction      = prediction.strip()
			prediction      = processPunctuation(prediction)
			prediction      = processDigitArticle(prediction)
			temp_count=0

			for _truth in truth.split(';'):
				_truth      = _truth.replace('\n', ' ')
				_truth      = _truth.replace('\t', ' ')
				_truth      = _truth.strip()
				_truth      = processPunctuation(_truth)
				_truth      = processDigitArticle(_truth)
				if prediction == _truth:
					temp_count+=1

			if temp_count>2:
				correct_val+=1
			else:
				correct_val+= float(temp_count)/3

			total+=1
		# f1.write(question.encode('utf-8'))
		# f1.write('\n')
		# f1.write(image.encode('utf-8'))
		# f1.write('\n')
		# f1.write(prediction)
		# f1.write('\n')
		# f1.write(truth.encode('utf-8'))
		# f1.write('\n')
		# f1.write('\n')

	# f1.write('Final Accuracy is ' + str(correct_val/total))
	# f1.close()
	f1 = open('../results/overall_results.txt', 'a')
	f1.write(weights_file_name + '\n')
	f1.write(str(correct_val/total) + '\n')
	f1.close()
	print 'Accuracy on the validation set is', correct_val/total
#
if __name__ == "__main__":
	print 'Getting VQA Model'
	vqa_model = model_from_json(open(VQA_model_file_name).read())
	vqa_model.load_weights(VQA_weights_file_name)
	vqa_model.compile(optimizer='rmsprop', loss={'output': 'categorical_crossentropy'})

	print 'Loading vgg features..'
	features_struct = scipy.io.loadmat(vgg_model_path)
	VGGfeatures = features_struct['feats']

	print 'Loading GLOVE vectors..'
	nlp = spacy.load('en', vectors='en_glove_cc_300_1m_vectors')
	ValEval(vqa_model,VGGfeatures,nlp,VQA_weights_file_name)
